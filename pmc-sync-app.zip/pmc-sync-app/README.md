# PMC Attachment Sync

A Streamlit app that pulls image files from a Google Drive folder and attaches
each one to the matching row in a Smartsheet — matched by comparing the image's
file name (minus extension) to a chosen "ID" column on the sheet.

Built so you can plug in more PMC companies later: each company is just one
more `[connections.*]` block in `secrets.toml`, no code changes needed.

## How matching works

1. The app lists every image in a given Google Drive folder.
2. It reads every row of a given Smartsheet, looking at one column (e.g. `ID 2`).
3. If a row's `ID 2` value matches an image's file name (without extension,
   case-insensitive), that image gets uploaded as an attachment on that row.
4. If a row already has an attachment with that exact file name, it's skipped
   (no duplicate uploads on repeat syncs).
5. Images with no matching row, and rows with no matching image, are both
   flagged so you can see what's missing.

## 1. Google Cloud setup (one-time)

This app authenticates to Drive with a plain **API key** rather than a service
account, so there's no consent flow and no JSON key file to manage. The
tradeoff: API keys can only see **public** content, so the target folder (and
every image inside it) has to be link-shareable.

1. Go to the [Google Cloud Console](https://console.cloud.google.com/), create
   or pick a project.
2. Enable the **Google Drive API** for that project (APIs & Services > Library).
3. Go to **APIs & Services > Credentials > Create Credentials > API key**.
4. Click **Restrict key** and limit it to the Google Drive API — this stops
   the key from being usable against your other Google Cloud services if it
   ever leaks.
5. In Google Drive, right-click the folder containing the images >
   **Share > General access > Anyone with the link** (Viewer is enough).
   Every image file inside also needs to inherit or have this same sharing
   setting.
6. Copy the folder's ID from its URL:
   `https://drive.google.com/drive/folders/<THIS_PART_IS_THE_ID>`

## 2. Smartsheet setup (one-time)

1. In Smartsheet, go to **Account > Personal Settings > API Access** and
   generate an API access token.
2. Open the target sheet, and grab its Sheet ID from **File > Properties**
   (or from the URL).
3. Make sure the sheet has a column to match on (default name used here:
   `ID 2`) whose values correspond to the image file names.

## 3. Configure secrets

Copy the example file and fill in your real values:

```bash
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Edit `.streamlit/secrets.toml` and fill in:
- `smartsheet_api_token`
- `smartsheet_sheet_id`
- `match_column_name` (defaults to `ID 2`)
- `gdrive_folder_id`
- `gdrive_api_key`

This file is already gitignored — never commit real secrets.

⚠️ Because Drive access here uses a public API key, **anything in that folder
is reachable by anyone with the folder link**, not just your app. Don't use
this approach for sensitive images, and don't index/share the link anywhere
public.

## 4. Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## 5. Deploy on Streamlit Community Cloud

1. Push this repo to GitHub (secrets.toml will **not** be included, since it's
   gitignored — that's intentional).
2. Go to [share.streamlit.io](https://share.streamlit.io), connect your
   GitHub repo, and set the main file to `app.py`.
3. In the app's **Settings > Secrets**, paste the entire contents of your
   local `.streamlit/secrets.toml` (this is Streamlit Cloud's secure secrets
   store, separate from the repo).
4. Deploy. Every time you push to the connected branch, the app redeploys.

## Adding another PMC company later

Just add another block to `secrets.toml` (locally and in Streamlit Cloud's
secrets manager):

```toml
[connections.pmc_acme]
name = "Acme PMC"
smartsheet_api_token = "..."
smartsheet_sheet_id = 9876543210
match_column_name = "ID 2"
gdrive_folder_id = "..."
gdrive_api_key = "..."  # can reuse the same key as other connections
```

It'll show up automatically in the connection dropdown at the top of the app —
no code changes required.

## Project structure

```
app.py                          # Streamlit UI + sync orchestration
utils/gdrive.py                 # Google Drive API helpers
utils/smartsheet_client.py      # Smartsheet API helpers
.streamlit/secrets.toml.example # Template for your real secrets file
requirements.txt
```
